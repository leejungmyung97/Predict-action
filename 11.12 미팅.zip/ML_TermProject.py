import warnings

from imblearn.over_sampling import SMOTE
warnings.filterwarnings(action='ignore')

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split, GridSearchCV, StratifiedKFold, cross_val_score
from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
import matplotlib.pyplot as plt
from yellowbrick.classifier import ROCAUC
from sklearn import metrics
from sklearn.metrics import confusion_matrix, classification_report
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
import seaborn as sns

dataset = pd.read_csv('mpii_human_pose.csv')

category_df = dataset
category_df['new'] = np.nan

cate_list = dataset['Activity'].astype('category').values.categories

# yoga
category_df.loc[category_df['Activity'] == 'yoga, Power', 'new'] = 'yoga'
category_df.loc[category_df['Activity'] == 'yoga, Nadisodhana', 'new'] = 'yoga'
category_df.loc[category_df['Activity'] == 'stretching', 'new'] = 'yoga'
# category_df.loc[category_df['Activity'] == 'pilates, general', 'new'] = 'yoga'
print('yoga: ' + str(len(category_df.loc[category_df['new'] == 'yoga', :])))  # 340

# manmom
# category_df.loc[category_df['Activity'] == 'video exercise workouts, TV conditioning programs', 'new'] = 'manmom'
# category_df.loc[category_df['Activity'] == 'resistance training', 'new'] = 'resistance'
# category_df.loc[category_df['Activity'] == 'circuit training', 'new'] = 'resistance'
# category_df.loc[category_df['Activity'] == 'aerobic, step', 'new'] = 'aerobic'

# category_df.loc[category_df['Activity'] == 'calisthenics', 'new'] = 'yoga'
# category_df.loc[category_df['Activity'] == 'home exercise, general', 'new'] = 'home'
# category_df.loc[category_df['Activity'] == 'slide board exercise, general', 'new'] = 'slide board'
# category_df.loc[category_df['Activity'] == 'stretching', 'new'] = 'manmom'
# category_df.loc[category_df['Activity'] == 'rope skipping, general', 'new'] = 'rope'
# print('manmom: ' + str(len(category_df.loc[category_df['new'] == 'manmom', :]))) # 1024

# rowing
category_df.loc[category_df['Activity'] == 'rowing, stationary', 'new'] = 'rowing'
print('rowing: ' + str(len(category_df.loc[category_df['new'] == 'rowing', :])))  # 150

# skiing
# ski_list = getContainList(cate_list, 'skiing')
# category_df.loc[((category_df['Activity'].isin(ski_list)) &
#                 (category_df['Category'] == 'winter activities')), 'new'] = 'skiing'
# print('ski: ' + str(len(category_df.loc[category_df['new'] == 'skiing', :]))) # 355

# running
category_df.loc[category_df['Category'] == 'running', 'new'] = 'running'
print('running: ' + str(len(category_df.loc[category_df['new'] == 'running', :])))  # 291

# skateboarding
# category_df.loc[category_df['Activity'] == 'skateboarding', 'new'] = 'skateboarding'
# print('skateboarding: ' + str(len(category_df.loc[category_df['new'] == 'skateboarding', :]))) # 184

# baseball
# category_df.loc[category_df['Activity'] == 'softball, general', 'new'] = 'baseball'
# print('baseball: ' + str(len(category_df.loc[category_df['new'] == 'baseball', :]))) # 173

# soccer
# category_df.loc[category_df['Activity'] == 'soccer', 'new'] = 'soccer'
# print('soccer: ' + str(len(category_df.loc[category_df['new'] == 'soccer', :]))) # 137

# golf
category_df.loc[category_df['Activity'] == 'golf', 'new'] = 'golf'
print('golf: ' + str(len(category_df.loc[category_df['new'] == 'golf', :])))  # 138

# basketball
# category_df.loc[category_df['Activity'] == 'basketball', 'new'] = 'basketball'
# category_df.loc[category_df['Activity'] == 'basketball, game (Taylor Code 490)', 'new'] = 'basketball'
# print('basketball: ' + str(len(category_df.loc[category_df['new'] == 'basketball', :]))) # 170

category_df.dropna(axis=0, inplace=True)
X = category_df.drop(columns=['ID', 'NAME', 'Scale', 'Activity', 'Category', 'new'])

# category_df.dropna(axis=0, inplace=True)
# category_df['nose_X'] = (category_df['upper neck_X'] + category_df['head top_X'])/2
# category_df['nose_Y'] = (category_df['upper neck_Y'] + category_df['head top_Y'])/2
# X = category_df.drop(columns=['ID', 'NAME', 'Scale', 'Activity', 'Category', 'new',
#                             'pelvis_X','pelvis_Y', 'thorax_X', 'thorax_Y',
#                             'upper neck_X', 'upper neck_Y', 'head top_X', 'head top_Y'])

y = category_df['new']

scaledX = pd.DataFrame(StandardScaler().fit_transform(X.transpose()))
# encode_y = LabelEncoder().fit_transform(y)

sm = SMOTE()
x_resample, y_resample = sm.fit_resample(scaledX.transpose(), y)

print(dataset.head())
print(dataset.describe())
print(dataset.info())




# Decision Tree Entropy
def dteClassifier(X_train, Y_train, X_test, Y_test):
    dte = DecisionTreeClassifier(criterion="entropy")
    dte.fit(X_train, Y_train)
    print(dte.score(X_test, Y_test))


# Decision Tree Gini
def dtgClassifier(X_train, Y_train, X_test, Y_test):
    dtg = DecisionTreeClassifier(criterion="gini")
    dtg.fit(X_train, Y_train)
    print(dtg.score(X_test, Y_test))


# Logistic Regression
def logisticRegr(X_train, y_train, X_test, y_test):
    logisticRegr = LogisticRegression(solver='lbfgs')
    logisticRegr.fit(X_train, y_train)
    logisticRegr.predict(X_train[0].reshape(1, -1))
    logisticRegr.predict(X_train[0:10])
    predictions = logisticRegr.predict(y_test)
    score = logisticRegr.score(X_test, y_test)
    print(score)


# SVC
def svc(X_train, y_train, X_test, y_test):
    # create an SVC classifier model
    svclassifier = SVC(kernel='linear')
    # fit the model to train dataset
    svclassifier.fit(X_train, y_train)
    # make predictions using the trained model
    y_pred = svclassifier.predict(X_test)
    print(svclassifier.score(X_test, y_test))



# evaluation each model
def evaluation(x, y, classifier):
    X_train, X_test, Y_train, Y_test = train_test_split(x, y, test_size=0.2, shuffle=True, random_state=1)
    skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=1)
    score = cross_val_score(classifier, X_train, Y_train, cv=skf)
    print(classifier, '\nCross validation score :', score)
    classifier.fit(X_train, Y_train)
    print('Accuracy on test set :', classifier.score(X_test, Y_test))
    print('')


listClassifier = [DecisionTreeClassifier(criterion="entropy"), DecisionTreeClassifier(criterion="gini"),
                  LogisticRegression(), SVC()]

# listBestDf index 0=DecisionTree(entropy), 1=DecisionTree(gini) 2=LogisticRegression, 3=SVC

for i in range(len(listClassifier)):
    evaluation(x_resample, y_resample, listClassifier[i])

# grid Decision Tree Entropy
X_train, X_test, y_train, y_test = train_test_split(x_resample, y_resample, test_size=0.2, shuffle=True, random_state=1)
param_grid = [{'max_features': np.arange(1, len(X_test.columns)), 'max_depth': np.arange(1, 20)}]
dt_entropy_gscv = GridSearchCV(listClassifier[0], param_grid, cv=2)
dt_entropy_gscv.fit(X_train, y_train)
print(dt_entropy_gscv.best_params_)
print('Best score :', dt_entropy_gscv.best_score_)

# grid Decision Tree Gini
X_train, X_test, y_train, y_test = train_test_split(x_resample, y_resample, test_size=0.2, shuffle=True, random_state=1)
param_grid = [{'max_features': np.arange(1, len(X_test.columns)), 'max_depth': np.arange(1, 10)}]
dt_gini_gscv = GridSearchCV(listClassifier[1], param_grid, cv=2, n_jobs=2)
dt_gini_gscv.fit(X_train, y_train)
print(dt_gini_gscv.best_params_)
print('Best score :', dt_gini_gscv.best_score_)

# grid Logistic Regression
X_train, X_test, y_train, y_test = train_test_split(x_resample, y_resample, test_size=0.2, shuffle=True, random_state=1)
param_grid = {'C': [0.001, 0.01, 0.1, 1, 10, 100, 1000],
              'penalty': ['l1', 'l2']}
lr_gscv = GridSearchCV(listClassifier[2], param_grid, cv=2, n_jobs=2)
lr_gscv.fit(X_train, y_train)
print(lr_gscv.best_params_)
print('Best score :', lr_gscv.best_score_)

# grid SVC
X_train, X_test, y_train, y_test = train_test_split(x_resample, y_resample, test_size=0.2, shuffle=True, random_state=1)
param_grid = {'C': [0.1, 1, 10, 100, 1000],
              'gamma': [1, 0.1, 0.01, 0.001, 0.0001],
              'kernel': ['rbf', 'poly', 'sigmoid']}
svc_gscv = GridSearchCV(listClassifier[3], param_grid, cv=2, n_jobs=2)
svc_gscv.fit(X_train, y_train)
print(svc_gscv.best_params_)
print('Best score :', svc_gscv.best_score_)

# print('\n---------After GridSearchCV---------\n')
# dt_e = DecisionTreeClassifier(max_depth=10, max_features=29, criterion="entropy")
# dt_g = DecisionTreeClassifier(max_depth=9, max_features=24, criterion="gini")
# lr = LogisticRegression(C=100, penalty="l2")
# svc = SVC(C=10, gamma=0.1, kernel='rbf')

# evaluation(listBestDf[0], y, dt_e)
# evaluation(listBestDf[1], y, dt_g)
# evaluation(listBestDf[2], y, lr)
# evaluation(listBestDf[3], y, svc)

# visulization

# Decision Tree(entropy)
dte_best = DecisionTreeClassifier(max_depth=10, max_features=29, criterion="entropy")
dte_best.fit(x_resample, y_resample)
X_train, X_test, Y_train, Y_test = train_test_split(x_resample, y_resample, test_size=0.2, shuffle=True, random_state=1)
print(confusion_matrix(Y_test, dte_best.predict(X_test)))
plt.figure(figsize=(2, 2))
ax = sns.heatmap(metrics.confusion_matrix(Y_test, dte_best.predict(X_test)), annot=True, fmt='.2f', linewidths=.1, cmap='Blues')
plt.title("Heatmap of Decision Tree(entropy)")
plt.show()

visualizer = ROCAUC(dte_best, classes=['golf', 'rowing', 'running', 'yoga'], micro=False, macro=True, per_class=False)
visualizer.fit(x_resample, y_resample)
visualizer.score(x_resample, y_resample)
visualizer.show()

print("classification_report using Decision Tree(entropy)")
print(classification_report(Y_test, dte_best.predict(X_test)))

# Decision Tree(gini)
dtg_best = DecisionTreeClassifier(max_depth=9, max_features=24, criterion="gini")
dtg_best.fit(x_resample, y_resample)
X_train, X_test, Y_train, Y_test = train_test_split(x_resample, y_resample, test_size=0.2, shuffle=True, random_state=1)
print(confusion_matrix(Y_test, dtg_best.predict(X_test)))
plt.figure(figsize=(2, 2))
ax = sns.heatmap(metrics.confusion_matrix(Y_test, dtg_best.predict(X_test)), annot=True, fmt='.2f', linewidths=.1, cmap='Blues')
plt.title("Heatmap of Decision Tree(gini)")
plt.show()

visualizer = ROCAUC(dte_best, classes=['golf', 'rowing', 'running', 'yoga'], micro=False, macro=True, per_class=False)
visualizer.fit(x_resample, y_resample)
visualizer.score(x_resample, y_resample)
visualizer.show()

print("classification_report using Decision Tree(gini)")
print(classification_report(Y_test, dte_best.predict(X_test)))

# LogisticRegression
lr_best = LogisticRegression(C=100, penalty="l2")
lr_best.fit(x_resample, y_resample)
X_train, X_test, Y_train, Y_test = train_test_split(x_resample, y_resample, test_size=0.2, shuffle=True, random_state=1)
print(confusion_matrix(Y_test, lr_best.predict(X_test)))
plt.figure(figsize=(2, 2))
ax = sns.heatmap(metrics.confusion_matrix(Y_test, lr_best.predict(X_test)), annot=True, fmt='.2f', linewidths=.1, cmap='Blues')
plt.title("Heatmap of Logistic Regression")
plt.show()

visualizer = ROCAUC(lr_best, classes=['golf', 'rowing', 'running', 'yoga'], micro=False, macro=True, per_class=False)
visualizer.fit(x_resample, y_resample)
visualizer.score(x_resample, y_resample)
visualizer.show()

print("classification_report using Logistic Regression")
print(classification_report(Y_test, lr_best.predict(X_test)))

# SVM
svc_best = SVC(C=10, gamma=0.1, kernel='rbf')
svc_best.fit(x_resample, y_resample)
X_train, X_test, Y_train, Y_test = train_test_split(x_resample, y_resample, test_size=0.2, shuffle=True, random_state=1)
print(confusion_matrix(Y_test, svc_best.predict(X_test)))
plt.figure(figsize=(2, 2))
ax = sns.heatmap(metrics.confusion_matrix(Y_test, svc_best.predict(X_test)), annot=True, fmt='.2f', linewidths=.1, cmap='Blues')
plt.title("Heatmap of Support Vector Machine")
plt.show()

visualizer = ROCAUC(svc_best, classes=['golf', 'rowing', 'running', 'yoga'], micro=False, macro=True, per_class=False)
visualizer.fit(x_resample, y_resample)
visualizer.score(x_resample, y_resample)
visualizer.show()

print("classification_report using Support Vector Machine")
print(classification_report(Y_test, svc_best.predict(X_test)))


